# LEVEL 1 — FUNDAMENTALS

Materi lengkap untuk pemula. Disusun bertahap supaya mudah dipelajari dan langsung bisa dipraktikkan. Formatnya mudah disalin ke Notion.

Level 1 punya tiga modul:

[Modul 01: Dasar Affiliate Marketing](LEVEL%201%20%E2%80%94%20FUNDAMENTALS/Modul%2001%20Dasar%20Affiliate%20Marketing%203f7522c2d0f680f8a717cc9a838906b8.md)

[Modul 02: Shopee Affiliate Program dan Kebijakan](LEVEL%201%20%E2%80%94%20FUNDAMENTALS/Modul%2002%20Shopee%20Affiliate%20Program%20dan%20Kebijakan%203f7522c2d0f680ff99ccf34753f88d04.md)

[Modul 03: Persiapan Akun dan Operasional](LEVEL%201%20%E2%80%94%20FUNDAMENTALS/Modul%2003%20Persiapan%20Akun%20dan%20Operasional%203f7522c2d0f68082b8d2eee1b9ac394e.md)

**Tujuan Level 1:** membangun fondasi yang benar sebelum kamu memilih produk, membuat konten, mendatangkan traffic, dan mengejar penjualan.

**Catatan penting:** aturan komisi, pendaftaran, atribusi, pembayaran, dan pajak Shopee Affiliate bisa berubah. Karena itu materi ini memisahkan dua hal:

- konsep dasar yang relatif tetap, dan
- aturan program yang harus kamu cek di sumber resmi terbaru.

Angka simulasi di materi ini bukan tarif resmi Shopee.
