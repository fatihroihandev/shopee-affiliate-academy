# LEVEL 4 — CONVERSION AND ANALYTICS

Tujuan level ini bukan sekadar mendapat banyak views atau klik. Kamu belajar mencari tahu:

- konten mana yang menghasilkan transaksi,
- produk mana yang menguntungkan, dan
- perubahan apa yang benar-benar menaikkan komisi.

[Modul 14 — Affiliate Link dan Tracking](LEVEL%204%20%E2%80%94%20CONVERSION%20AND%20ANALYTICS/Modul%2014%20%E2%80%94%20Affiliate%20Link%20dan%20Tracking%203f7522c2d0f6804cb65aff04cfaeb697.md)

[Modul 15 — Conversion Rate Optimization (CRO)](LEVEL%204%20%E2%80%94%20CONVERSION%20AND%20ANALYTICS/Modul%2015%20%E2%80%94%20Conversion%20Rate%20Optimization%20(CRO)%203f7522c2d0f68001bf36f98965e9ebee.md)

[Modul 16 — Analytics dan Dashboard](LEVEL%204%20%E2%80%94%20CONVERSION%20AND%20ANALYTICS/Modul%2016%20%E2%80%94%20Analytics%20dan%20Dashboard%203f7522c2d0f680f7a7e6f2efc69d5d6b.md)

[Modul 17 — Eksperimen dan Validasi](LEVEL%204%20%E2%80%94%20CONVERSION%20AND%20ANALYTICS/Modul%2017%20%E2%80%94%20Eksperimen%20dan%20Validasi%203f7522c2d0f680c8ab05cad494c21701.md)

## Hasil akhir Level 4

- Database Link Affiliate yang rapi dan link yang sudah diuji.
- Peta funnel dari views sampai pembayaran, lengkap dengan tahap yang paling lemah.
- Dashboard Notion dengan CTR, CVR, EPC, dan komisi per 1.000 views.
- Tiga eksperimen pertama yang terdokumentasi di Database Eksperimen.
